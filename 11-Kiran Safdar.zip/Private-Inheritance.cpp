#include<iostream>
using namespace std;
class parent{
    public:
    int a;
    protected:
    int b;
    private:
    int c;
};
class child:private parent{
   public:
   void in(){
    cout<<"Enter a:";
    cin>>a;
    cout<<"Enter b:";
    cin>>b;
   }
   void out(){
    cout<<"a="<<a<<endl;
    cout<<"b="<<endl;
   }
};
int main(){
    child obj;
    obj.in();
    obj.out();
    
}