#include<iostream>
using namespace std;
class Teacher{
	public:
		void Teach(){
			cout<<"teaching............"<<endl;
		}
};
class Student:public Teacher{
public:
	void learn(){
		cout<<"learning..........,"<<endl;
	}
};
int main(){
	Student a;
	a.Teach();
	return 0;
}