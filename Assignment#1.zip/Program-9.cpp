#include <iostream>
#include <cmath> // For M_PI

// Abstract base class
class Shape {
public:
    virtual ~Shape() {}

    // Pure virtual functions
    virtual void draw() = 0;
    virtual double getArea() = 0;
};
class Circle : public Shape {
private:
    double radius;

public:
    Circle(double r) : radius(r) {}

    void draw()  override {
        std::cout << "Drawing a circle with radius " << radius << std::endl;
        // Here you would add code to actually draw the circle using a graphics library
    }

    double getArea()  override {
        return M_PI * radius * radius;
    }
};
class Rectangle : public Shape {
private:
    double width;
    double height;

public:
    Rectangle(double w, double h) : width(w), height(h) {}

    void draw()  override {
        std::cout << "Drawing a rectangle with width " << width << " and height " << height << std::endl;
        // Here you would add code to actually draw the rectangle using a graphics library
    }

    double getArea()  override {
        return width * height;
    }
};
class Triangle : public Shape {
private:
    double base;
    double height;

public:
    Triangle(double b, double h) : base(b), height(h) {}

    void draw()  override {
        std::cout << "Drawing a triangle with base " << base << " and height " << height << std::endl;
        // Here you would add code to actually draw the triangle using a graphics library
    }

    double getArea()  override {
        return 0.5 * base * height;
    }
};

int main() {
    // Create instances of each shape
    Shape* circle = new Circle(5.0);
    Shape* rectangle = new Rectangle(4.0, 6.0);
    Shape* triangle = new Triangle(3.0, 4.0);

    // Array of pointers to Shape objects
    Shape* shapes[] = { circle, rectangle, triangle };

    // Iterate over the array and use each shape
    for (const Shape* shape : shapes) {
        shape->draw();
        std::cout << "Area: " << shape->getArea() << std::endl;
        std::cout << std::endl;  // Empty line for better readability
    }

    // Clean up
    delete circle;
    delete rectangle;
    delete triangle;

    return 0;
}
