#include <iostream>
#include <cmath>  // For mathematical functions if needed
using namespace std;
// Abstract base class
class Shape {
public:
    // Pure virtual function to calculate the area
    virtual double calculateArea() = 0; 
};

// Derived class Square
class Square : public Shape {
public:
    // Constructor to initialize the side length
    Square(double side) : side_(side) {}

    // Override the pure virtual function
    double calculateArea()  override {
        return side_ * side_;  // Area of the square
    }

private:
    double side_;
};

// Derived class Triangle
class Triangle : public Shape {
public:
    // Constructor to initialize the base and height
    Triangle(double base, double height) : base_(base), height_(height) {}

    // Override the pure virtual function
    double calculateArea()  override {
        return 0.5 * base_ * height_;  // Area of the triangle
    }

private:
    double base_;
    double height_;
};

int main() {
    // Create objects of Square and Triangle
    Square mySquare(4.0);  // Side length of 4.0
    Triangle myTriangle(3.0, 5.0);  // Base 3.0 and height 5.0

    // Create an array of Shape pointers
    Shape* shapes[2];
    shapes[0] = &mySquare;
    shapes[1] = &myTriangle;

    // Display the area for each shape
    for (int i = 0; i < 2; ++i) {
        std::cout << "Area: " << shapes[i]->calculateArea() << std::endl;
    }

    return 0;
}
