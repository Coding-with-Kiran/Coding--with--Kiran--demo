#include <iostream>
#include <vector>
using namespace std;
// Abstract Base Class
class Account {
public:
    virtual void calculateInterest() = 0; // Pure virtual function
};

// Derived Class for Savings Account
class SavingsAccount : public Account {
private:
    double balance;
    double annualInterestRate;

public:
    SavingsAccount(double bal, double rate)
        : balance(bal), annualInterestRate(rate) {}

    void calculateInterest()  override {
        double interest = balance * (annualInterestRate / 100);
        cout << "Savings Account Interest: $" << interest <<endl;
    }
};

// Derived Class for Checking Account
class CheckingAccount : public Account {
private:
    double balance;
    double fixedInterest;

public:
    CheckingAccount(double bal, double fixedInt)
        : balance(bal), fixedInterest(fixedInt) {}

    void calculateInterest()  override {
	cout << "Checking Account Interest: $" << fixedInterest <<endl;
    }
};

int main() {
    // Create objects of SavingsAccount and CheckingAccount
    SavingsAccount savings(1000, 2.5);
    CheckingAccount checking(2000, 50);

    // Create an array of pointers to Account
    vector<Account*> accounts;

    // Add objects to the array
    accounts.push_back(&savings);
    accounts.push_back(&checking);

    // Calculate and display interest for each account
    for (const auto& account : accounts) {
        account->calculateInterest();
    }

    return 0;
}
