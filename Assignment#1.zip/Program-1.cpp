#include<iostream>
using namespace std;
class Base{
	public:
	virtual void show()=0;
};
class Derv1:public Base{
	public:
	void show() override{
		cout<<"child is Derv1"<<endl;
	}
};
class Derv2:public Base{
	public:
	void show() override{
		cout<<"child is Derv2"<<endl;
	}
};
int main(){
	Derv1 d1;
	Derv2 d2;
	Base *b1=&d1;
	Base *b2=&d2;
	b1->show();
	b2->show();	
}