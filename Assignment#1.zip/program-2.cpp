#include <iostream>
using namespace std;
// Base class
class Vehicle {
public:
    // Virtual function to get the number of wheels
    virtual int getNumberOfWheels() = 0;  // Pure virtual function
};

// Derived class Car
class Car : public Vehicle {
public:
    // Override the pure virtual function
    int getNumberOfWheels()  override {
        return 4;  // Cars typically have 4 wheels
    }
};

// Derived class Bike
class Bike : public Vehicle {
public:
    // Override the pure virtual function
    int getNumberOfWheels()  override {
        return 2;  // Bikes typically have 2 wheels
    }
};

int main() {
    // Create objects of Car and Bike
    Car myCar;
    Bike myBike;

    // Create an array of Vehicle pointers
    Vehicle* vehicles[2];

    // Assign Car and Bike objects to the Vehicle pointers
    vehicles[0] = &myCar;
    vehicles[1] = &myBike;

    // Display the number of wheels for each vehicle
    for (int i = 0; i < 2; ++i) {
    cout << "Number of wheels: " << vehicles[i]->getNumberOfWheels() <<endl;
    }

    return 0;
}
