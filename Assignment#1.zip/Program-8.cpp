#include <iostream>
#include <string>

// Abstract base class
class PaymentMethod {
public:
    virtual ~PaymentMethod() {}

    // Pure virtual functions
    virtual void processPayment(double amount) = 0;
    virtual void refund(double amount) = 0;
};
class CreditCard : public PaymentMethod {
public:
    void processPayment(double amount) override {
        std::cout << "Processing credit card payment of $" << amount << std::endl;
        // Here you would add code to process the payment through a credit card API
    }

    void refund(double amount) override {
        std::cout << "Refunding $" << amount << " to credit card" << std::endl;
        // Here you would add code to process the refund through a credit card API
    }
};
class PayPal : public PaymentMethod {
public:
    void processPayment(double amount) override {
        std::cout << "Processing PayPal payment of $" << amount << std::endl;
        // Here you would add code to process the payment through PayPal API
    }

    void refund(double amount) override {
        std::cout << "Refunding $" << amount << " via PayPal" << std::endl;
        // Here you would add code to process the refund through PayPal API
    }
};
class BankTransfer : public PaymentMethod {
public:
    void processPayment(double amount) override {
        std::cout << "Processing bank transfer payment of $" << amount << std::endl;
        // Here you would add code to process the payment through a bank transfer system
    }

    void refund(double amount) override {
        std::cout << "Refunding $" << amount << " via bank transfer" << std::endl;
        // Here you would add code to process the refund through a bank transfer system
    }
};
int main() {
    // Create instances of each payment method
    PaymentMethod* creditCard = new CreditCard();
    PaymentMethod* payPal = new PayPal();
    PaymentMethod* bankTransfer = new BankTransfer();

    // Process payments and refunds for each payment method
    creditCard->processPayment(100.0);
    creditCard->refund(50.0);

    payPal->processPayment(200.0);
    payPal->refund(75.0);

    bankTransfer->processPayment(300.0);
    bankTransfer->refund(125.0);

    // Clean up
    delete creditCard;
    delete payPal;
    delete bankTransfer;

    return 0;
}
