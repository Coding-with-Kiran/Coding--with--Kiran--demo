#include <iostream>
#include <cmath> // For sqrt and M_PI

// Abstract base class
class Shape {
public:
    virtual ~Shape() {}

    // Pure virtual functions
    virtual double area() = 0;
    virtual double perimeter() = 0;
};
class Circle : public Shape {
private:
    double radius;

public:
    Circle(double r) : radius(r) {}

    double area()  override {
        return M_PI * radius * radius;
    }

    double perimeter()  override {
        return 2 * M_PI * radius;
    }
};
class Rectangle : public Shape {
private:
    double length;
    double width;

public:
    Rectangle(double l, double w) : length(l), width(w) {}

    double area()  override {
        return length * width;
    }

    double perimeter()  override {
        return 2 * (length + width);
    }
};
class Triangle : public Shape {
private:
    double side1;
    double side2;
    double side3;

public:
    Triangle(double s1, double s2, double s3) : side1(s1), side2(s2), side3(s3) {}

    double area()  override {
        // Using Heron's formula
        double s = (side1 + side2 + side3) / 2;
        return sqrt(s * (s - side1) * (s - side2) * (s - side3));
    }

    double perimeter()  override {
        return side1 + side2 + side3;
    }
};
int main() {
    // Create instances of each shape
    Shape* circle = new Circle(5.0);
    Shape* rectangle = new Rectangle(4.0, 6.0);
    Shape* triangle = new Triangle(3.0, 4.0, 5.0);

    // Array of pointers to Shape objects
    Shape* shapes[] = { circle, rectangle, triangle };

    // Iterate over the array and use each shape
    for (const Shape* shape : shapes) {
        std::cout << "Area: " << shape->area() << std::endl;
        std::cout << "Perimeter: " << shape->perimeter() << std::endl;
        std::cout << std::endl;  // Empty line for better readability
    }

    // Clean up
    delete circle;
    delete rectangle;
    delete triangle;

    return 0;
}
