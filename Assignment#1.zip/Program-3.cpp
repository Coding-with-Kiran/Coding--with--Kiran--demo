#include <iostream>
using namespace std;
// Base class
class Shape {
public:
    // Virtual function to draw the shape
    virtual void draw() = 0;  // Pure virtual function
};

// Derived class Circle
class Circle : public Shape {
public:
    // Override the pure virtual function
    void draw() override {
	cout << "Drawing a Circle." <<endl;
    }
};

// Derived class Rectangle
class Rectangle : public Shape {
public:
    // Override the pure virtual function
    void draw()  override {
    cout << "Drawing a Rectangle." <<endl;
    }
};

int main() {
    // Create objects of Circle and Rectangle
    Circle myCircle;
    Rectangle myRectangle;

    // Create an array of Shape pointers
    Shape* shapes[2];

    // Assign Circle and Rectangle objects to the Shape pointers
    shapes[0] = &myCircle;
    shapes[1] = &myRectangle;

    // Draw each shape using the Shape pointers
    for (int i = 0; i < 2; ++i) {
        shapes[i]->draw();
    }

    return 0;
}
