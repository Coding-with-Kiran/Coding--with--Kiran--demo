#include <iostream>
#include <string>

// Base class
class Fruit {
protected:
    std::string color;

public:
    // Constructor to initialize the color
    Fruit(const std::string& color) : color(color) {}

    // Pure virtual functions to be overridden by subclasses
    virtual std::string taste() = 0;
    virtual std::string eatingMethod() = 0;

    // Method to describe the fruit
    std::string describe()  {
        return "This fruit is " + color + ".";
    }
};

// Derived class Apple
class Apple : public Fruit {
public:
    // Constructor
    Apple() : Fruit("red") {}

    // Override taste method
    std::string taste()  override {
        return "Apples taste sweet and tangy.";
    }

    // Override eatingMethod method
    std::string eatingMethod()  override {
        return "Apples are usually eaten raw, often with the skin on.";
    }
};

// Derived class Banana
class Banana : public Fruit {
public:
    // Constructor
    Banana() : Fruit("yellow") {}

    // Override taste method
    std::string taste()  override {
        return "Bananas taste sweet and creamy.";
    }

    // Override eatingMethod method
    std::string eatingMethod()  override {
        return "Bananas are usually eaten raw, peeled before eating.";
    }
};

// Main function
int main() {
    // Create instances of Apple and Banana
    Apple apple;
    Banana banana;

    // Array of pointers to Fruit objects
    Fruit* fruits[] = { &apple, &banana };

    // Iterate over the array and display information
    for ( Fruit* fruit : fruits) {
        std::cout << fruit->describe() << std::endl;
        std::cout << fruit->taste() << std::endl;
        std::cout << fruit->eatingMethod() << std::endl;
        std::cout << std::endl;  // Empty line for better readability
    }

    return 0;
}
