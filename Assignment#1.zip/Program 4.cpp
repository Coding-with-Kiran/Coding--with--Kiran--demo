#include <iostream>
using namespace std;
// Base class
class Employee {
public:
    // Virtual function to calculate the salary
    virtual double calculateSalary() = 0;  // Pure virtual function
};

// Derived class FullTimeEmployee
class FullTimeEmployee : public Employee {
public:
    // Constructor to initialize the salary
    FullTimeEmployee(double baseSalary) : baseSalary_(baseSalary) {}

    // Override the pure virtual function
    double calculateSalary()  override {
        return baseSalary_;  // Full-time employees get a fixed salary
    }

private:
    double baseSalary_;
};

// Derived class PartTimeEmployee
class PartTimeEmployee : public Employee {
public:
    // Constructor to initialize hours worked and hourly wage
    PartTimeEmployee(double hoursWorked, double hourlyWage) 
        : hoursWorked_(hoursWorked), hourlyWage_(hourlyWage) {}

    // Override the pure virtual function
    double calculateSalary()  override {
        return hoursWorked_ * hourlyWage_;  // Part-time employees get paid based on hours worked
    }

private:
    double hoursWorked_;
    double hourlyWage_;
};

int main() {
    // Create objects of FullTimeEmployee and PartTimeEmployee
    FullTimeEmployee ftEmployee(5000.00);  // Fixed salary of $5000
    PartTimeEmployee ptEmployee(20, 15.00); // 20 hours worked at $15/hour

    // Use base class pointers to call the calculateSalary() function
    Employee* employees[2];
    employees[0] = &ftEmployee;
    employees[1] = &ptEmployee;

    // Display the salary for each employee
    for (int i = 0; i < 2; ++i) {
        std::cout << "Salary: $" << employees[i]->calculateSalary() << std::endl;
    }

    return 0;
}
